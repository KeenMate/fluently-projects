﻿namespace $ext_safeprojectname$.TestConsole.Data.Enums
{
	public enum MenuAction
	{
		None,
		ServiceStart,
		ServicePause,
		ServiceContinue,
		ServiceStop,
		ServiceShutdown,
		Exit
	}
}