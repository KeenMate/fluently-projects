﻿namespace $ext_safeprojectname$.TestConsole.Data.Enums
{
	public enum RenderPosition
	{
		Top,
		TopLeft,
		TopRight,
		Left,
		Center,
		Bottom,
		BottomLeft,
		BottomRight,
		Right
	}
}