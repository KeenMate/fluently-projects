﻿using System;

namespace $ext_safeprojectname$.TestConsole.Data.Exceptions
{
	public class InvalidTypeException : Exception
	{ }
}