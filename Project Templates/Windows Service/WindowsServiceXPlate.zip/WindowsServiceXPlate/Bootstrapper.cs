﻿using System;
using System.Threading.Tasks;
using System.Timers;
using $ext_safeprojectname$.Data.Enums;
using NLog;

namespace $ext_safeprojectname$
{
	/// <summary>
	/// User's code
	/// </summary>
	public class Bootstrapper
	{
		public ServiceState CurrentState { get; set; } = ServiceState.Stopped;

		private readonly ILogger logger = LogManager.GetLogger("ConsoleLogger");
		private readonly Guid correlationId;

		public Bootstrapper(Guid correlationId)
		{
			this.correlationId = correlationId;
		}

		public void Start()
		{
			logger.Debug($"{correlationId} - {nameof(Start)} method Called");

			CurrentState = ServiceState.Started;
		}

		public void Stop()
		{
			logger.Debug($"{correlationId} - {nameof(Stop)} method Called");

			CurrentState = ServiceState.Stopped;
		}

		public void Continue()
		{
			logger.Debug($"{correlationId} - {nameof(Continue)} method Called");

			CurrentState = ServiceState.Resumed;
		}

		public void Pause()
		{
			logger.Debug($"{correlationId} - {nameof(Pause)} method Called");

			CurrentState = ServiceState.Paused;
		}

		public void Shutdown()
		{
			logger.Debug($"{correlationId} - {nameof(Shutdown)} method Called");

			CurrentState = ServiceState.Shutdowned;
		}
	}
}
