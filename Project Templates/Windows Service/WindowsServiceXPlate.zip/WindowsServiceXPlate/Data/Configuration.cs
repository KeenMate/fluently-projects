namespace $ext_safeprojectname$.Data
{
	public class Configuration
	{
		public int TimerInterval { get; set; }

		public int IntValue { get; set; }

		public string StringValue { get; set; }
	}
}