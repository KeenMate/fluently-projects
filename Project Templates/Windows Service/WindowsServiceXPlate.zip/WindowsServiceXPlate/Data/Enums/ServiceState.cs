﻿namespace $ext_safeprojectname$.Data.Enums
{
	public enum ServiceState
	{
		Started,
		Paused,
		Stopped,
		Resumed,
		Shutdowned
	}
}