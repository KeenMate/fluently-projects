

namespace $safeprojectname$.Providers {
	public class DataProvider {
		
	}
}